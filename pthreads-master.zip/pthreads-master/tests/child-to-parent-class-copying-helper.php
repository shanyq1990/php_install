<?php

class ExternalBaseClass extends \Threaded {}
